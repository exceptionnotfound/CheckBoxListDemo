﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CheckBoxListDemo.Web.ViewModels.Movie
{
    public class EditMovieVM : AddMovieVM
    {
        public int ID { get; set; }
    }
}